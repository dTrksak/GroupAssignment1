
package edu.metrostate.ics372_androidstart_master;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InfoActivity extends AppCompatActivity {

    private TextView data;
    private EditText warehouseID;
    private Button addWarehouse;
    private Button addShipment;
    private Button removeShipment;
    private Button printAll;
    private Button printOne;
    private WarehouseHandler handle = WarehouseHandler.getInstance();
    private List<Shipment> printData = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        data = (TextView) findViewById(R.id.data);
        addWarehouse = (Button) findViewById(R.id.addWarehouse);
        addShipment = (Button) findViewById(R.id.addShipment);
        removeShipment = (Button) findViewById(R.id.removeShipment);
        printAll = (Button) findViewById(R.id.printAll);
        printOne = (Button) findViewById(R.id.printOne);
        warehouseID = (EditText) findViewById(R.id.printWarehouse);

        addShipment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addShipment();
            }

        });

        removeShipment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeShipment();
            }
        });

        printAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                printAll();
            }
        });

        printOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                printOne();
            }
        });

    }

    private void printOne() {
        String warehouseId = warehouseID.getText().toString();
        printData = handle.getWarehouseShipments(warehouseId);
        data.setText(printData.toString());
        data.setMovementMethod(new ScrollingMovementMethod());
    }

    private void printAll() {
        printData = handle.getAllWarehouseShipments();
        data.setText(printData.toString());
        data.setMovementMethod(new ScrollingMovementMethod());
    }


    private void addShipment() {
        Intent intent = new Intent(this, AddShipment.class);
        startActivity(intent);
    }

    private void removeShipment() {
        Intent intent = new Intent(this, RemoveShipment.class);
        startActivity(intent);
    }

}

