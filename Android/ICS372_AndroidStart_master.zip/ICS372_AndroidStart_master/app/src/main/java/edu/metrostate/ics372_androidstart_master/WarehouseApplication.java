package edu.metrostate.ics372_androidstart_master;

import android.app.Application;

public class WarehouseApplication extends Application {
}
